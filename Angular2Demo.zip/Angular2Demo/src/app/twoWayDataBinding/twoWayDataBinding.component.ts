﻿import { Component } from '@angular/core';

@Component({
    selector: "my-app5",
    templateUrl: "app/twoWayDataBinding/twoWayDataBinding.component.html"
})

export class twoWaytwoWayDataBindingComponent {
    fullName: string = "Raqif"; 
}